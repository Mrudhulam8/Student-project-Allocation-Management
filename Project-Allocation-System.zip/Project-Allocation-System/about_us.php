
<html>
    <head>
        <title>Project Allocation</title>
        <link rel='icon' href="favicon.ico">
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="Robot" content="index,follow,project,allocation,distribution,subject"/>
        <meta name="Description" content="Online Project Allocation is available over here"/>
        <link rel="stylesheet" type="text/css" href="main.css">
    </head>
    <body>
        <h1 align="center">Student Project Allocation System</h1>
        <h3 align="center"><a href="index.php"  class="back shadow"><= Back</a></h3>
        <br>
        
            <h4 align="center">
&emsp;&emsp;                Welcome to our project of PHP<br><br>
&emsp;&emsp;                subject - Student Project Allocation System<br><br>
&emsp;&emsp;                ---<br><br>
&emsp;&emsp;&emsp;                ---<br>
&emsp;&emsp;&emsp;                ---<br>
&emsp;&emsp;&emsp;                ---<br>
&emsp;&emsp;&emsp;                ---</h4>
        
    </body>
</html>
