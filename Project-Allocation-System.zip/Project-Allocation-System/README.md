# Project-Allocation-System
A student project allocation system in PHP.

### Author : VATSAL JAGANI
Supporter : Axit Jariwala
            Hiren Italiya
            Mohit Jain

## DATABASE
database sql file for import from phpmyAdmin is inside images/database
for more details about tables pdf file available at same place

## ADMIN/ALLOCATION
here admin can change allocation process
here is the main logic for allocationg the projects to groups by means od average cpi of group members
flush.php  is for master resetting database

## ADMIN login & logout

## STUDENT login
student login is from index.php main home page

## CHANGE & FORGOT PASSWORD
inside chang_pass foler all files related to
forgot password
change password
creating captcha
and javascript file for validating

## STUDENT 
home page
student logout

for creating group

for selection of projects for group
for arranging projects as per choise

## ADMIN
student.php
faculty.php &
project.php
this files is for gui to display them

## ABOUT_US.PHP
for just display about project and creator

## F   S   P
folders for
	adding
	deleting
	updating
	desabling/enabling
	changing password by admin
	javascript file for validating input
	
faculty, student and projects 

// faculty can access only by admin 
// other thing can access by any faculty
